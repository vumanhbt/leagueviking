<?php // File: partials/tabs_content/cocaugiaithuong_content.php ?>
<h2>Cơ Cấu Giải Thưởng</h2>
<p>Thông tin chi tiết về giải thưởng của giải đấu.</p>
<ul>
    <li>Giải Nhất: ...</li>
    <li>Giải Nhì: ...</li>
    <li>Giải Ba: ...</li>
</ul>