<?php
// File: partials/footer.php
?>
        </main>

        <footer class="text-center mt-5 py-3 border-top">
            <p>&copy; <?php echo date("Y"); ?> <?php echo SITE_NAME; ?> - Phát triển bởi Robin Nguyễn.</p>
            <p><a href="https://2vikingbilliards.com/" target="_blank">2Viking Billiards</a></p>
        </footer>
    </div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo SITE_URL; ?>assets/js/script.js"></script> </body>
</html>