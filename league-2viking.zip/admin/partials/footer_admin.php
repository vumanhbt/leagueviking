<?php
// File: admin/partials/footer_admin.php
?>
</div> <footer class="text-center mt-5 py-3 border-top bg-light">
    <p>&copy; <?php echo date("Y"); ?> <?php echo SITE_NAME; ?> - Admin Panel.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>